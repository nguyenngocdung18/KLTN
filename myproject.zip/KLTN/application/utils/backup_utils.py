import json
import os
from pathlib import Path

BACKUP_FILE = "certificates_backup.json"

def save_certificate(certificate_id, uid, candidate_name, course_name, org_name, ipfs_hash):
    """Lưu thông tin certificate vào file backup"""
    data = {
        "certificate_id": certificate_id,
        "uid": uid,
        "candidate_name": candidate_name,
        "course_name": course_name,
        "org_name": org_name,
        "ipfs_hash": ipfs_hash
    }
    
    # Đọc dữ liệu hiện có
    existing_data = []
    if os.path.exists(BACKUP_FILE):
        with open(BACKUP_FILE, 'r', encoding='utf-8') as f:
            existing_data = json.load(f)
    
    # Thêm certificate mới
    existing_data.append(data)
    
    # Lưu lại file
    with open(BACKUP_FILE, 'w', encoding='utf-8') as f:
        json.dump(existing_data, f, ensure_ascii=False, indent=2)

def get_all_certificates():
    """Đọc tất cả certificate từ file backup"""
    if os.path.exists(BACKUP_FILE):
        with open(BACKUP_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

def restore_certificates(contract, account):
    """Khôi phục các certificate vào blockchain"""
    certificates = get_all_certificates()
    for cert in certificates:
        try:
            # Lấy thông tin certificate trên blockchain
            cert_on_chain = contract.functions.getCertificate(cert["certificate_id"]).call()
            exists = cert_on_chain[7]  # exists
            
            if not exists:
                # Chỉ thêm vào blockchain nếu chưa tồn tại
                contract.functions.generateCertificate(
                    cert["certificate_id"],
                    cert["uid"],
                    cert["candidate_name"],
                    cert["course_name"],
                    cert["org_name"],
                    cert["ipfs_hash"]
                ).transact({'from': account})
                print(f"Restored certificate for {cert['candidate_name']}")
            else:
                print(f"Certificate for {cert['candidate_name']} already exists.")
        except Exception as e:
            print(f"Error restoring certificate {cert['certificate_id']}: {str(e)}") 
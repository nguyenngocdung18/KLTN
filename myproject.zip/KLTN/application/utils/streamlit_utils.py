import streamlit as st
import base64
import requests
import os
from connection import contract


def displayPDF(file):
    # Opening file from file path
    with open(file, "rb") as f:
        base64_pdf = base64.b64encode(f.read()).decode('utf-8')

    # Embedding PDF in HTML
    pdf_display = F'<iframe src="data:application/pdf;base64,{base64_pdf}" width="700" height="1000" type="application/pdf"></iframe>'

    # Displaying File
    st.markdown(pdf_display, unsafe_allow_html=True)


def view_certificate(certificate_id, gateway_url=None):
    try:
        # Smart Contract Call
        result = contract.functions.getCertificate(certificate_id).call()
        ipfs_hash = result[5]  # Lấy IPFS hash từ kết quả

        # Sử dụng Pinata gateway
        pinata_gateway_base_url = 'https://gateway.pinata.cloud/ipfs'
        content_url = f"{pinata_gateway_base_url}/{ipfs_hash}"
        
        response = requests.get(content_url)
        if response.status_code == 200:
            # Lưu file PDF tạm thời
            temp_pdf_path = os.path.join(os.path.dirname(__file__), "temp.pdf")
            with open(temp_pdf_path, 'wb') as pdf_file:
                pdf_file.write(response.content)
            # Hiển thị PDF
            displayPDF(temp_pdf_path)
            # Xóa file tạm sau khi hiển thị
            if os.path.exists(temp_pdf_path):
                os.remove(temp_pdf_path)
        else:
            st.error(f"Không thể tải file từ IPFS. Lỗi: {response.status_code}")
    except Exception as e:
        st.error(f"Lỗi khi xem chứng chỉ: {str(e)}")


def hide_icons():
    hide_st_style = """
                <style>
                #MainMenu {visibility: hidden;}
                footer {visibility: hidden;}
                </style>"""
    st.markdown(hide_st_style, unsafe_allow_html=True)


def hide_sidebar():
    no_sidebar_style = """
                <style>
                div[data-testid="stSidebarNav"] {visibility: hidden;}
                </style>"""
    st.markdown(no_sidebar_style, unsafe_allow_html=True)


def remove_whitespaces():
    st.markdown("""
        <style>
               .css-18e3th9 {
                    padding-top: 0rem;
                    padding-bottom: 10rem;
                    padding-left: 5rem;
                    padding-right: 5rem;
                }
               .css-1d391kg {
                    padding-top: 3.5rem;
                    padding-right: 1rem;
                    padding-bottom: 3.5rem;
                    padding-left: 1rem;
                }
        </style>""", unsafe_allow_html=True)

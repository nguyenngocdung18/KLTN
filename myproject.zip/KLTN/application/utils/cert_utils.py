from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import pdfplumber
import os
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_LEFT

# Đăng ký font chữ DejaVu Serif
font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"
pdfmetrics.registerFont(TTFont('DejaVuSerif', font_path))

def add_watermark(canvas, doc):
    # Thêm watermark (logo quốc huy) làm nền
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    watermark_path = os.path.join(base_dir, "assets", "quochuy.jpg")
    if os.path.exists(watermark_path):
        canvas.saveState()
        # Vẽ watermark ở giữa trang với độ trong suốt
        canvas.setFillAlpha(0.1)  # Đặt độ trong suốt
        canvas.drawImage(watermark_path, 
                        x=(A4[0]-200)/2,  # Căn giữa theo chiều ngang
                        y=(A4[1]-200)/2,  # Căn giữa theo chiều dọc
                        width=200, 
                        height=200,
                        mask='auto')
        canvas.restoreState()

def generate_certificate(output_path, uid, candidate_name, course_name, org_name, institute_logo_path, 
                    graduation_year, grade, education_type, issue_date, certificate_number, book_number):
    print(f"Starting certificate generation...")
    print(f"Output path: {output_path}")
    print(f"Logo path: {institute_logo_path}")
    
    try:
        # Create a PDF document with A4 size
        doc = SimpleDocTemplate(output_path, pagesize=A4, 
                          topMargin=30,
                          bottomMargin=30,
                          leftMargin=30,
                          rightMargin=30,
                          title="Certificate",
                          author="HCMUS",
                          subject="Academic Certificate",
                          keywords="certificate,academic,degree")
        print("Created SimpleDocTemplate")
        
        # Create a list to hold the elements of the PDF
        elements = []

        # Thiết lập background màu trắng cho toàn bộ trang
        elements.append(Paragraph('<para backcolor="white"></para>', 
                            ParagraphStyle('background', backColor=colors.white)))
        print("Added white background")

        # Style cho tiêu đề "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM"
        header_style = ParagraphStyle(
            "HeaderStyle",
            parent=getSampleStyleSheet()["Title"],
            fontName="DejaVuSerif",
            fontSize=14,
            alignment=1,  # Căn giữa
            spaceAfter=6,
            textColor=colors.black,  # Đảm bảo màu chữ là đen
        )
        print("Created styles")
        
        # Style cho tên trường
        school_style = ParagraphStyle(
            "SchoolStyle",
            parent=getSampleStyleSheet()["Title"],
            fontName="DejaVuSerif",
            fontSize=14,
            alignment=1,  # Căn giữa
            spaceAfter=20,
            textColor=colors.black,  # Đảm bảo màu chữ là đen
        )
        
        # Style cho "HIỆU TRƯỞNG"
        principal_style = ParagraphStyle(
            "PrincipalStyle",
            parent=getSampleStyleSheet()["Title"],
            fontName="DejaVuSerif",
            fontSize=14,
            alignment=1,  # Căn giữa
            spaceAfter=6,
            textColor=colors.black,  # Đảm bảo màu chữ là đen
        )

        # Style cho "BẰNG CỬ NHÂN"
        degree_style = ParagraphStyle(
            "DegreeStyle",
            parent=getSampleStyleSheet()["Title"],
            fontName="DejaVuSerif",
            fontSize=20,
            alignment=1,  # Căn giữa
            textColor=colors.red,
            spaceAfter=20,
        )

        # Style cho thông tin sinh viên (căn trái)
        info_style = ParagraphStyle(
            "InfoStyle",
            parent=getSampleStyleSheet()["Normal"],
            fontName="DejaVuSerif",
            fontSize=12,
            alignment=0,  # Căn trái
            leading=20,
            textColor=colors.black,  # Đảm bảo màu chữ là đen
        )

        # Style cho tên sinh viên (to và nghiêng)
        student_name_style = ParagraphStyle(
            "StudentNameStyle",
            parent=getSampleStyleSheet()["Normal"],
            fontName="DejaVuSerif",
            fontSize=24,  # Gấp đôi font size thông thường
            alignment=0,  # Căn trái
            leading=30,
            textColor=colors.black,
            italic=True,  # In nghiêng
        )

        # Style cho chữ ký hiệu trưởng
        signature_style = ParagraphStyle(
            "SignatureStyle",
            parent=getSampleStyleSheet()["Normal"],
            fontName="DejaVuSerif",
            fontSize=12,
            alignment=2,  # Căn phải
            leading=20,
            textColor=colors.black,  # Đảm bảo màu chữ là đen
        )

        # Style cho số hiệu và số vào sổ (căn trái)
        number_style = ParagraphStyle(
            "NumberStyle",
            parent=getSampleStyleSheet()["Normal"],
            fontName="DejaVuSerif",
            fontSize=10,
            alignment=0,  # Căn trái
            leading=15,
            textColor=colors.black,  # Đảm bảo màu chữ là đen
        )

        # Thêm các phần tử vào PDF
        elements.append(Paragraph("CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", header_style))
        elements.append(Paragraph("Độc lập - Tự do - Hạnh phúc", header_style))
        elements.append(Spacer(1, 20))
        print("Added header text")

        # Logo trường
        if institute_logo_path and os.path.exists(institute_logo_path):
            print(f"Logo file exists at: {institute_logo_path}")
            logo = Image(institute_logo_path, width=100, height=100)
            logo.hAlign = 'CENTER'  # Căn giữa logo
            elements.append(logo)
        else:
            print(f"Logo file not found at: {institute_logo_path}")
        elements.append(Spacer(1, 10))
        
        try:
            # Hiệu trưởng và tên trường
            elements.append(Paragraph("HIỆU TRƯỞNG", principal_style))
            elements.append(Paragraph("TRƯỜNG ĐẠI HỌC KHOA HỌC TỰ NHIÊN", school_style))
            elements.append(Paragraph("cấp", school_style))
            elements.append(Spacer(1, 10))

            # Bằng cử nhân
            elements.append(Paragraph("BẰNG CỬ NHÂN", degree_style))
            elements.append(Spacer(1, 20))

            # Thông tin sinh viên
            elements.append(Paragraph("Cho:", info_style))
            elements.append(Paragraph(candidate_name, student_name_style))
            elements.append(Paragraph(f"Ngành: {course_name}", info_style))
            elements.append(Paragraph(f"Hình thức: {education_type}", info_style))
            elements.append(Paragraph(f"Xếp loại tốt nghiệp: {grade}", info_style))
            elements.append(Paragraph(f"Năm tốt nghiệp: {graduation_year}", info_style))
            elements.append(Spacer(1, 20))

            # Chữ ký hiệu trưởng sử dụng table
            signature_table = Table([
                [Paragraph(f"TP. Hà Nội, {issue_date}", signature_style)],
                [Paragraph("", info_style)],  # Thêm khoảng trống
                [Paragraph("Hiệu trưởng", signature_style)]
            ], colWidths=[500])  # Điều chỉnh độ rộng của cột

            signature_table.setStyle(TableStyle([
                ('ALIGN', (0, 0), (0, 0), 'RIGHT'),  # Căn phải cho dòng địa điểm và ngày
                ('ALIGN', (0, 2), (0, 2), 'RIGHT'),  # Căn phải cho dòng Hiệu trưởng để nó nằm giữa phần ngày tháng
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('LEFTPADDING', (0, 0), (-1, -1), 0),
                ('RIGHTPADDING', (0, 0), (-1, -1), 0),
                ('TOPPADDING', (0, 0), (-1, -1), 0),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
                ('BACKGROUND', (0, 0), (-1, -1), colors.white),  # Đảm bảo nền trắng cho bảng
            ]))

            elements.append(signature_table)
            elements.append(Spacer(1, 40))  # Khoảng trống cho chữ ký

            # Số hiệu và số vào sổ
            elements.append(Paragraph(f"Số hiệu: {certificate_number}", number_style))
            elements.append(Paragraph(f"Số vào sổ cấp bằng: {book_number}", number_style))

            # Build the PDF document with watermark
            doc.build(elements, onFirstPage=add_watermark)
            print(f"PDF generated successfully at: {output_path}")
            if os.path.exists(output_path):
                print(f"PDF file exists and has size: {os.path.getsize(output_path)} bytes")
            else:
                print("PDF file was not created")
        except Exception as build_error:
            print(f"Error building PDF: {str(build_error)}")
            raise build_error
            
    except Exception as e:
        print(f"Error in generate_certificate: {str(e)}")
        raise e

def extract_certificate(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        # Extract text from each page
        text = ""
        for page in pdf.pages:
            text += page.extract_text()
        lines = text.splitlines()

        certificate_number = lines[4].replace("Số hiệu: ", "")  # Số hiệu
        book_number = lines[5].replace("Số vào sổ cấp bằng: ", "")  # Số vào sổ
        candidate_name = lines[10].replace("Cho: ", "")  # Tên sinh viên
        course_name = lines[11].replace("Ngành: ", "")  # Ngành
        education_type = lines[12].replace("Hình thức: ", "")  # Hình thức đào tạo
        grade = lines[13].replace("Xếp loại tốt nghiệp: ", "")  # Xếp loại
        graduation_year = lines[14].replace("Năm tốt nghiệp: ", "")  # Năm tốt nghiệp

        return (certificate_number, candidate_name, course_name, org_name, graduation_year, grade, education_type, book_number)
    

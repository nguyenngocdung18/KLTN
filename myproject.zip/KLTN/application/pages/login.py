import streamlit as st
from db.firebase_app import login
from dotenv import load_dotenv
import os
from utils.streamlit_utils import hide_icons, hide_sidebar, remove_whitespaces
from streamlit_extras.switch_page_button import switch_page

st.set_page_config(layout="wide", initial_sidebar_state="collapsed")
hide_icons()
hide_sidebar()
remove_whitespaces()

load_dotenv()

# Kiểm tra xem người dùng có phải là Institute không
if "role" not in st.session_state or st.session_state.role != "Institute":
    switch_page("app")

form = st.form("login")
email = form.text_input("Nhập email của bạn")
password = form.text_input("Nhập mật khẩu của bạn", type="password")
submit = form.form_submit_button("Đăng nhập")

if submit:
    valid_email = os.getenv("institute_email")
    valid_pass = os.getenv("institute_password")
    if email == valid_email and password == valid_pass:
        st.success("Đăng nhập thành công!")
        switch_page("institute")
    else:
        st.error("Thông tin đăng nhập không hợp lệ!")
        

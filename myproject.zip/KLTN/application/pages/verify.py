# application/pages/verify.py
import streamlit as st
from utils.streamlit_utils import hide_icons, hide_sidebar, remove_whitespaces, view_certificate
from connection import contract

# Page configuration
st.set_page_config(page_title="Public Verify", layout="wide")
hide_icons()
hide_sidebar()
remove_whitespaces()

st.title("🔍 Xác minh Chứng chỉ Công khai")

# Input certificate ID
d_cert_id = st.text_input("Nhập ID Chứng chỉ", key="verify_id")

# Verify button
if st.button("Xác minh Chứng chỉ"):
    if not d_cert_id:
        st.warning("Vui lòng nhập ID Chứng chỉ.")
    else:
        try:
            # Check if certificate exists and not revoked
            verified = contract.functions.isVerified(d_cert_id).call()
            if not verified:
                st.error("❌ Không tìm thấy chứng chỉ hoặc chứng chỉ đã bị thu hồi.")
            else:
                st.success("✅ Chứng chỉ hợp lệ.")
                # Fetch certificate details
                details = contract.functions.getCertificate(d_cert_id).call()
                st.write("**Mã số:**", details[0])
                st.write("**Họ tên:**", details[1])
                st.write("**Khóa học:**", details[2])
                st.write("**Tổ chức:**", details[3])
                # Display PDF from IPFS
                view_certificate(d_cert_id)
        except Exception as e:
            st.error(f"Lỗi khi xác minh chứng chỉ: {e}")


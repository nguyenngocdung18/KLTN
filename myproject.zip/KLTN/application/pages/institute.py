import streamlit as st
import requests
import json
import os
from dotenv import load_dotenv
import hashlib
import pandas as pd
from utils.cert_utils import generate_certificate
from utils.streamlit_utils import view_certificate
from utils.backup_utils import save_certificate, restore_certificates
from connection import contract, w3
from utils.streamlit_utils import hide_icons, hide_sidebar, remove_whitespaces
import base64
import time

st.set_page_config(layout="wide", initial_sidebar_state="collapsed")
hide_icons()
hide_sidebar()
remove_whitespaces()

load_dotenv()

# Khôi phục certificates khi khởi động ứng dụng
try:
    restore_certificates(contract, w3.eth.accounts[0])
except Exception as e:
    print(f"Error restoring certificates: {str(e)}")

api_key = os.getenv("PINATA_API_KEY")
api_secret = os.getenv("PINATA_API_SECRET")


def upload_to_pinata(file_path, api_key, api_secret):
    # Set up the Pinata API endpoint and headers
    pinata_api_url = "https://api.pinata.cloud/pinning/pinFileToIPFS"
    headers = {
        "pinata_api_key": api_key,
        "pinata_secret_api_key": api_secret,
    }

    # Prepare the file for upload
    with open(file_path, "rb") as file:
        filename = os.path.basename(file_path)
        files = {
            "file": (filename, file, "application/pdf")
        }

        # Make the request to Pinata
        response = requests.post(pinata_api_url, headers=headers, files=files)

        # Parse the response
        result = json.loads(response.text)

        if "IpfsHash" in result:
            ipfs_hash = result["IpfsHash"]
            print(f"File uploaded to Pinata. IPFS Hash: {ipfs_hash}")
            return ipfs_hash
        else:
            print(f"Error uploading to Pinata: {result.get('error', 'Unknown error')}")
            return None


def get_all_certificates():
    try:
        total_certs = contract.functions.getTotalCertificates().call()
        all_certs = []
        for i in range(total_certs):
            cert_id = contract.functions.getCertificateIdByIndex(i).call()
            cert_details = contract.functions.getCertificate(cert_id).call()
            is_revoked = cert_details[6]  # index 6 là trường revoked
            all_certs.append({
                'ID': cert_id[:8] + "...",  # Hiển thị 8 ký tự đầu của ID
                'Full ID': cert_id,
                'Student Name': cert_details[2],  # index 2 là candidateName
                'Course': cert_details[3],  # index 3 là courseName
                'Status': "Revoked" if is_revoked else "Valid"
            })
        return pd.DataFrame(all_certs)
    except Exception as e:
        st.error(f"Error fetching certificates: {str(e)}")
        return pd.DataFrame()


def get_next_uid():
    try:
        total_certs = contract.functions.getTotalCertificates().call()
        return total_certs + 1
    except Exception as e:
        st.error(f"Error getting next UID: {str(e)}")
        return 1


options = ("Tạo Chứng chỉ", "Quản lý Chứng chỉ", "Xem Chứng chỉ")
selected = st.selectbox("", options, label_visibility="hidden")

if selected == options[0]:
    form = st.form("Generate-Certificate")
    candidate_name = form.text_input(label="Họ và tên")
    course_name = form.text_input(label="Tên khóa học")
    graduation_year = form.text_input(label="Năm tốt nghiệp")
    grade = form.selectbox(label="Xếp loại", options=["Xuất sắc", "Giỏi","Khá", "Trung bình", "Yếu"])
    education_type = form.selectbox(
        label="Loại hình đào tạo", 
        options=["Tài năng", "Chất lượng cao", "Chuẩn", "Tiên tiến", "Đạt chuẩn quốc tế"]
    )
    issue_date = form.text_input(label="Ngày cấp (ví dụ: ngày 20 tháng 05 năm 2025)")

    submit = form.form_submit_button("Tạo chứng chỉ")
    if submit:
        try:
            uid = str(get_next_uid())
            certificate_number = f"HUS/{uid}"
            book_number = f"HUS/{uid}/{graduation_year}"
            org_name = "ĐẠI HỌC KHOA HỌC TỰ NHIÊN"
            
            # Tạo đường dẫn tuyệt đối cho file PDF
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            pdf_file_path = os.path.join(base_dir, "certificate.pdf")
            institute_logo_path = os.path.join(base_dir, "assets", "institute_logo.jpg")
            
            print(f"Base directory: {base_dir}")
            print(f"PDF will be saved at: {pdf_file_path}")
            print(f"Logo path: {institute_logo_path}")
            
            if not os.path.exists(institute_logo_path):
                st.error(f"Logo file not found at {institute_logo_path}")
            else:
                print("Logo file exists, proceeding with certificate generation...")
                try:
                    # Tạo chứng chỉ
                    generate_certificate(
                        pdf_file_path, 
                        uid, 
                        candidate_name, 
                        course_name, 
                        org_name, 
                        institute_logo_path,
                        graduation_year,
                        grade,
                        education_type,
                        issue_date,
                        certificate_number,
                        book_number
                    )
                    
                    print("Checking if PDF was generated...")
                    if os.path.exists(pdf_file_path):
                        print(f"PDF file exists at {pdf_file_path}")
                        print(f"PDF file size: {os.path.getsize(pdf_file_path)} bytes")
                        
                        # Hiển thị PDF trước
                        with open(pdf_file_path, "rb") as pdf_file:
                            pdf_bytes = pdf_file.read()
                            st.download_button(
                                label="Tải xuống Chứng chỉ PDF",
                                data=pdf_bytes,
                                file_name="certificate.pdf",
                                mime="application/pdf"
                            )
                            st.write("Xem trước Chứng chỉ:")
                            base64_pdf = base64.b64encode(pdf_bytes).decode('utf-8')
                            pdf_display = f'<iframe src="data:application/pdf;base64,{base64_pdf}" width="700" height="1000" type="application/pdf"></iframe>'
                            st.markdown(pdf_display, unsafe_allow_html=True)
                        
                        print("Uploading to Pinata...")
                        ipfs_hash = upload_to_pinata(pdf_file_path, api_key, api_secret)
                        if ipfs_hash:
                            print(f"Successfully uploaded to Pinata with hash: {ipfs_hash}")
                            # Xóa file PDF sau khi upload thành công và hiển thị
                            os.remove(pdf_file_path)
                            print("Deleted local PDF file")
                            
                            data_to_hash = f"{uid}{candidate_name}{course_name}{org_name}".encode('utf-8')
                            certificate_id = hashlib.sha256(data_to_hash).hexdigest()

                            print("Calling smart contract...")
                            # Smart Contract Call
                            contract.functions.generateCertificate(
                                certificate_id, 
                                uid, 
                                candidate_name, 
                                course_name, 
                                org_name, 
                                ipfs_hash
                            ).transact({'from': w3.eth.accounts[0]})
                            print("Smart contract call successful")
                            
                            # Lưu thông tin certificate vào backup
                            save_certificate(
                                certificate_id,
                                uid,
                                candidate_name,
                                course_name,
                                org_name,
                                ipfs_hash
                            )
                            
                            st.success(f"""Chứng chỉ đã được tạo thành công!
                            ID Chứng chỉ: {certificate_id}
                            Số hiệu Chứng chỉ: {certificate_number}
                            Số vào sổ: {book_number}
                            """)
                        else:
                            st.error("Không thể tải lên chứng chỉ lên IPFS")
                            print("Failed to upload to Pinata")
                    else:
                        st.error("Failed to generate certificate PDF")
                        print(f"PDF file does not exist at {pdf_file_path}")
                except Exception as e:
                    st.error(f"Error generating certificate: {str(e)}")
                    print(f"Detailed error in certificate generation: {str(e)}")
        except Exception as e:
            st.error(f"An error occurred: {str(e)}")
            print(f"Detailed error: {str(e)}")

elif selected == options[1]:
    st.subheader("Quản lý Chứng chỉ")
    
    # Lấy tất cả chứng chỉ và tạo DataFrame
    df = get_all_certificates()
    
    if not df.empty:
        # Thanh tìm kiếm
        search_term = st.text_input("Tìm kiếm theo tên sinh viên", "")
        
        # Lọc DataFrame theo tên sinh viên
        if search_term:
            df = df[df['Student Name'].str.contains(search_term, case=False)]
        
        # Hiển thị bảng với các nút hành động
        st.write("### Danh sách Chứng chỉ")
        
        # Tạo cột index bắt đầu từ 1
        df.index = range(1, len(df) + 1)
        
        # Hiển thị bảng với định dạng
        st.dataframe(
            df.style.apply(lambda x: ['background-color: #90EE90' if v == 'Valid' else 'background-color: #FFB6C1' 
                                    for v in x], subset=['Status'])
        )
        
        # Form để xem chi tiết hoặc thu hồi chứng chỉ
        with st.form("certificate_actions"):
            col1, col2 = st.columns(2)
            with col1:
                selected_index = st.number_input("Nhập số thứ tự để xem/thu hồi chứng chỉ", 
                                              min_value=1, max_value=len(df), step=1)
            with col2:
                action = st.selectbox("Chọn hành động", ["Xem chi tiết", "Thu hồi Chứng chỉ", "Cấp lại Chứng chỉ"])
            submit_action = st.form_submit_button("Xác nhận")

        # Xử lý sau khi submit form
        if submit_action and 1 <= selected_index <= len(df):
            selected_cert = df.iloc[selected_index - 1]
            if action == "Xem chi tiết":
                st.write("### Chi tiết Chứng chỉ")
                st.write(f"**ID đầy đủ:** {selected_cert['Full ID']}")
                st.write(f"**Họ tên:** {selected_cert['Student Name']}")
                st.write(f"**Khóa học:** {selected_cert['Course']}")
                st.write(f"**Trạng thái:** {selected_cert['Status']}")
                
                if selected_cert['Status'] == "Valid":
                    view_certificate(selected_cert['Full ID'], gateway_url='https://ipfs.io/ipfs')
            elif action == "Thu hồi Chứng chỉ":
                if selected_cert['Status'] == "Valid":
                    try:
                        contract.functions.revokeCertificate(selected_cert['Full ID']).transact({'from': w3.eth.accounts[0]})
                        st.success("Chứng chỉ đã được thu hồi thành công!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Lỗi khi thu hồi chứng chỉ: {str(e)}")
                else:
                    st.warning("Chứng chỉ này đã bị thu hồi!")
            elif action == "Cấp lại Chứng chỉ":
                if selected_cert['Status'] == "Revoked":
                    try:
                        contract.functions.reissueCertificate(selected_cert['Full ID']).transact({'from': w3.eth.accounts[0]})
                        st.success("Chứng chỉ đã được cấp lại thành công!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Lỗi khi cấp lại chứng chỉ: {str(e)}")
                else:
                    st.warning("Chứng chỉ này vẫn còn hiệu lực!")
    else:
        st.info("No certificates found in the system.")

else:
    form = st.form("View-Certificate")
    certificate_id = form.text_input("Enter the Certificate ID")
    submit = form.form_submit_button("Submit")
    if submit:
        try:
            # Check if certificate exists and is not revoked
            is_valid = contract.functions.isVerified(certificate_id).call()
            if is_valid:
                view_certificate(certificate_id, gateway_url='https://ipfs.io/ipfs')
            else:
                st.error("Certificate has been revoked or does not exist!")
        except Exception as e:
            st.error("Invalid Certificate ID!")
        

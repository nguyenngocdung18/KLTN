import json
from pathlib import Path
from web3 import Web3

# Kết nối đến Ganache
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

# Kiểm tra kết nối
try:
    w3.eth.get_block_number()
except Exception as e:
    raise Exception("Không thể kết nối đến Ganache. Hãy đảm bảo Ganache đang chạy!")

def get_contract_abi():
    certification_json_path = Path('../build/contracts/Certificate.json')
    try:
        with open(certification_json_path, 'r') as json_file:
            certification_data = json.load(json_file)
            return certification_data.get('abi', [])
    except FileNotFoundError:
        print(f"Error: {certification_json_path} not found.")
        return []

contract_abi = get_contract_abi()
if not contract_abi:
    raise Exception("Không thể đọc ABI của contract")

deployment_config_fpath = Path("../deployment_config.json")
try:
    with open(deployment_config_fpath, 'r') as json_file:
        address_data = json.load(json_file)
    contract_address = address_data.get('Certificate')
    if not contract_address:
        raise Exception("Không tìm thấy địa chỉ contract trong file deployment_config.json")
except FileNotFoundError:
    raise Exception(f"Không tìm thấy file {deployment_config_fpath}")

# Tạo đối tượng contract
contract = w3.eth.contract(address=contract_address, abi=contract_abi)

# Kiểm tra contract có được deploy đúng không
try:
    total = contract.functions.getTotalCertificates().call()
    print(f"Total certificates: {total}")
except Exception as e:
    raise Exception(f"Không thể kết nối đến contract: {str(e)}")

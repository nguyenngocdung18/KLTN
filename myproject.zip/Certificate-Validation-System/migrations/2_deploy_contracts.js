let Certificate = artifacts.require("./Certificate.sol");
const fs = require('fs');

module.exports = async function (deployer) {
  await deployer.deploy(Certificate);
  const deployedCertificate = await Certificate.deployed();

  // Always start with an empty object for configData
  let configData = {};

  // Update or add the contract address
  configData.Certificate = deployedCertificate.address;

  // Save the updated configuration back to the file
  fs.writeFileSync('./deployment_config.json', JSON.stringify(configData, null, 2));

  console.log(`Certificate contract deployed at address: ${deployedCertificate.address}`);
};

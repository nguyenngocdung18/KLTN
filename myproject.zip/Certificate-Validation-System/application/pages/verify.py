# application/pages/verify.py
import streamlit as st
from utils.streamlit_utils import hide_icons, hide_sidebar, remove_whitespaces, view_certificate
from connection import contract

# Page configuration
st.set_page_config(page_title="Public Verify", layout="wide")
hide_icons()
hide_sidebar()
remove_whitespaces()

st.title("🔍 Public Certificate Verification")

# Input certificate ID
d_cert_id = st.text_input("Enter Certificate ID", key="verify_id")

# Verify button
if st.button("Verify Certificate"):
    if not d_cert_id:
        st.warning("Please enter a Certificate ID.")
    else:
        try:
            # Check if certificate exists and not revoked
            verified = contract.functions.isVerified(d_cert_id).call()
            if not verified:
                st.error("❌ Certificate not found or has been revoked.")
            else:
                st.success("✅ Certificate is valid.")
                # Fetch certificate details
                details = contract.functions.getCertificate(d_cert_id).call()
                st.write("**UID:**", details[0])
                st.write("**Name:**", details[1])
                st.write("**Course:**", details[2])
                st.write("**Organization:**", details[3])
                # Display PDF from IPFS
                view_certificate(d_cert_id)
        except Exception as e:
            st.error(f"Error verifying certificate: {e}")


# application/pages/select_role.py

import streamlit as st
from PIL import Image
from utils.streamlit_utils import hide_icons, hide_sidebar, remove_whitespaces
from streamlit_extras.switch_page_button import switch_page

st.set_page_config(layout="wide", initial_sidebar_state="collapsed")
hide_icons()
hide_sidebar()
remove_whitespaces()

st.title("Certificate Validation System")
st.subheader("Select Your Role")

# Tạo 2 cột cho 2 nút
col1, col2 = st.columns(2)

# Institute
institute_logo = Image.open("../assets/institute_logo.jpg")
with col1:
    st.image(institute_logo, width=200)
    if st.button("Institute"):
        st.session_state.role = "Institute"
        switch_page("login")

# Anonymous/Verifier
anon_logo = Image.open("../assets/andanh.png")
with col2:
    st.image(anon_logo, width=200)
    if st.button("Verify Certificate"):
        st.session_state.role = "Anonymous"
        switch_page("verify")


